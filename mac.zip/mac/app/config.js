'use strict';

exports.version = '0.1.0';
exports.id = 'com.mybrowseraddon.node';

exports.ids = {
  "chrome": [
    "chkcckbanhebciojejomifnieikldhpj", /* VLC */
    "ghmmojdgeboemapkmmdfaedgoehjebna"  /* Chrome */
  ],
  "firefox": [
    '064b93787dde695feb59b01ae03e27d20746c2f1@temporary-addon' /* Chrome */
  ]
};
