'use strict';

exports.version = '0.1.0';
exports.id = 'com.mybrowseraddon.node';

exports.ids = {
  "chrome": [
    "anlkimmcefcceiddhggegodhkgkndhic" /* Chrome */
  ],
  "firefox": [
    "jid1-r2yWXsZku2AJH2@jetpack" /* Chrome */
  ]
};
